#ifndef DAILOG_H
#define DAILOG_H

#include <QMainWindow>
#include"mythread.h"

QT_BEGIN_NAMESPACE
namespace Ui { class dailog; }
QT_END_NAMESPACE

class dailog : public QMainWindow
{
    Q_OBJECT

public:
    dailog(QWidget *parent = nullptr);
    ~dailog();
    mythread *mThread;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();
public slots:
    void on_valuechanged(int count);

private:
    Ui::dailog *ui;
};
#endif // DAILOG_H
