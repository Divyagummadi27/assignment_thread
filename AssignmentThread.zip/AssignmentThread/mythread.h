#ifndef MYTHREAD_H
#define MYTHREAD_H

#include<QObject>
#include<QThread>


class mythread:public QThread
{
    Q_OBJECT
public:
    explicit mythread(QObject *parent=0,bool b=false,bool c=false);
    void run();
    bool stop;
    bool set;
    int x,i;

signals:
    void valuechanged(int);
};

#endif // MYTHREAD_H
