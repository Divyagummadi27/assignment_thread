#include "dailog.h"
#include "ui_dailog.h"
#include "mythread.h"

dailog::dailog(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::dailog)
{
    ui->setupUi(this);
    mThread=new mythread(this,false,false);
    connect(mThread,SIGNAL(valuechanged(int)),this,SLOT(on_valuechanged(int)));
}

dailog::~dailog()
{
    delete ui;
}


void dailog::on_pushButton_clicked() //start button
{
 mThread->stop=false;
 mThread->set=true;
 mThread->start();
}

void dailog::on_pushButton_2_clicked() //stop button
{
  mThread->stop=true;
}

void dailog::on_pushButton_3_clicked()   //restart button
{
   mThread->stop=false;
   mThread->set=false;
   mThread->start();
}
void dailog::on_valuechanged(int count) //label
{
    ui->label->setText(QString::number(count));
}
