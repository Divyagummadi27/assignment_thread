#include "mythread.h"
#include<QMutex>
#include<QDebug>

mythread::mythread(QObject *parent,bool b,bool c):QThread(parent),stop(b),set(c)
{

}
void mythread::run()
{
    if(this->set){i=x;}
    else
    {
        i=0;
    }
    for( ;i<50;i++)
    {
        QMutex mutex;
        mutex.lock();
        if(this->stop)
        {
            x=i;
            mutex.unlock();  //prevent the other threads from changing the stop value
            break;
        }
        mutex.unlock();
        emit valuechanged(i); //emit the signal from count label
        this->msleep(500);
    }
}
